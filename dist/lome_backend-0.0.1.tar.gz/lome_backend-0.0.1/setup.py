# Lome Project
# @author Todd Saharchuk
# (c) Copyright 2023- , Todd Saharchuk
#

from setuptools import setup, find_packages

setup(
	name='lome_backend',
	version='0.0.1',
	author='Todd Saharchuk',
	author_email='todd.saharchuk@gmail.com',
	description='Python tools fragment and weaver for cli processing in the Lome system',
	packages=find_packages(),
	install_requires=[
		"clang==14.0"
	],
	entry_points = {
		'console_scripts': [
			'weaver = lome_backend.weaver:main',
			'fragmenter = lome_backend.fragmenter:main',
		]
	}
)