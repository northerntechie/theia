# Lome Project
# @author Todd Saharchuk
# (c) Copyright 2023- , Todd Saharchuk
#
import argparse
import json
import logging
import os
import shelve
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta

import constants
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

logging.basicConfig()
logging.root.setLevel(logging.NOTSET)

app = "fragmenter"
logger = logging.getLogger(app)
logger.setLevel(logging.INFO)
app_verbose = "fragmenter_verbose"
verbose_logger = logging.getLogger(app_verbose)
database_path = "./data.db"
file_types = [".cpp", ".h"]
db: any
int_dir = None


@dataclass
class FileInfo:
    filePath: os.path


src_files: FileInfo = []


class FileWatchHandler(FileSystemEventHandler):
    def __init__(self):
        self.last_modified = datetime.now()

    def on_created(self, event: FileSystemEvent):
        self.last_modified = datetime.now()
        logger.info(f"Watchdog received modified event - {event.src_path}.")

    def on_modified(self, event):
        # We need this to debounce temporary file creation events
        if datetime.now() - self.last_modified < timedelta(seconds=1):
            return
        else:
            self.last_modified = datetime.now()
            logger.info(
                f"Watchdog received modified event - "
                f"{event.src_path}."
            )


def processConfigFile():
    global database_path
    global file_types

    contents = ""
    with open(".fragbat.config.json", "r") as cf:
        jsonContents = cf.read()
        try:
            contents = json.loads(jsonContents)
        except json.JSONDecodeError:
            logger.error("index JSON file is ill-formed. Exiting...")
            sys.exit()

        if contents:
            if contents["db_path"]:
                database_path = contents["db_path"]
            if contents["file_types"]:
                file_types = contents["file_types"]

        logger.info(f"Set database path to: {database_path}")
        logger.info(f"Set files types to: {file_types}")


def buildFileInfo(filePath, origDir) -> FileInfo:
    fileInfo = FileInfo(filePath)
    fileInfo.filePath = filePath

    return fileInfo


def scanDirectory(root):
    global src_files

    for dirpath, dirnames, filenames in os.walk(root):
        for file in filenames:
            extension = os.path.splitext(file)[1]
            if extension in file_types:
                filePath = os.path.join(dirpath, file)
                logger.info(f"Found source file: {filePath}")
                fileInfo = buildFileInfo(file, dirpath)
                src_files.append(fileInfo)


def reprocess():
    pass


def process():
    global src_files
    global int_dir

    scanDirectory(args.root)
    # Assign intermediate directory
    if args.int_dir is None:
        int_dir = "./temp"
    else:
        int_dir = args.int_dir
    # Assign output
    output = None
    if args.output is None:
        output = "./output.fragments.json"
    else:
        output = args.output
    logger.info(
        f"args.output= {args.output}, args.root= {args.root}, "
        f"output= {output}, args.int_dir= {args.int_dir}"
    )

    subprocess.call(
        [
            "python",
            "fragmenter.py",
            args.entry_file,
            args.index_path,
            "-o",
            output,
            "-d",
            int_dir,
            "-v",
        ]
    )
    for file in src_files:
        if file.filePath == args.entry_file:
            continue  # We already processed you


def main():
    global db

    logger.info(f"Processing root path: {args.root}")
    logger.info(f"Index file: {args.index_path}")
    logger.info("Processing config file...")

    processConfigFile()
    db = shelve.open(database_path, writeback=True)

    process()

    if args.watch:
        event_handler = FileWatchHandler()
        observer = Observer()
        observer.schedule(event_handler, args.root, recursive=True)
        observer.start()

        try:
            while True:
                time.sleep(1)
        finally:
            observer.stop()
            observer.join()
            db.close()
        pass
    else:
        process()


if __name__ == "__main__":
    logger.info(
        f"Loom fragmenter batch runner version "
        f"{constants.MAJOR}.{constants.MINOR}.{constants.PATCH}"
    )

    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument(
        "root", help="This is the root directory path of the source files"
    )
    arg_parser.add_argument(
        "entry_file",
        help="Entry source file, usually main.cpp in C++ programs"
    )
    arg_parser.add_argument(
        "index_path", help="Index file path for appending index entries"
    )
    arg_parser.add_argument(
        "-w", "--watch", action="store_true", help="Enable watch mode"
    )
    arg_parser.add_argument("-o", "--output", help="Output file path")
    arg_parser.add_argument(
        "-i",
        "--int_dir",
        help="Intermediate directory path"
    )
    arg_parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )
    args = arg_parser.parse_args()

    main()
