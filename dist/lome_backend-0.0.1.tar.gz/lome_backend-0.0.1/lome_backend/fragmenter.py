#!/bin/python3
# Lome Project
# @author Todd Saharchuk
# (c) Copyright 2023- , Todd Saharchuk
#
import argparse
import glob
import hashlib
import json
import logging
import os
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from io import TextIOWrapper
from typing import List, Tuple

from clang.cindex import Config

print(f"sys.path: {sys.path}")
# Set the library path
Config.set_library_path('/usr/lib/x86_64-linux-gnu')
# Now you can import clang.cindex without errors
import clang.cindex  # noqa: E402

logging.basicConfig()
logging.root.setLevel(logging.NOTSET)

app = "fragmenter"
logger = logging.getLogger(app)
logger.setLevel(logging.INFO)
app_verbose = "fragmenter_verbose"
verbose_logger = logging.getLogger(app_verbose)
new_index_file = False
g_close_index_file = False


# General purpose classes
@dataclass
class SrcRange:
    start: int = 0  # Start position in character position in string/file
    end: int = 0


@dataclass
class Fragment:
    comment_range: SrcRange = None
    custom_index_text: str = ""
    custom_index_hash: hash = 0
    comment_text: str = ""
    function_declaration_range: SrcRange = None
    function_declaration_text: str = ""
    function_declaration_signature_text: str = ""
    function_declaration_hash: hash = 0
    function_scope_range: SrcRange = None
    function_text: str = ""
    is_custom_hash: bool = False
    start_line: int = 0
    source_file_path: str = ""


class EOLType(Enum):
    UNKNOWN = 0
    CR = 1
    LF = 2
    CRLF = 3
    LFCR = 4


# Global variables
MAJOR = 0
MINOR = 0
PATCH = 1

# Return code enumerations
RET_SUCCESS = 0
RET_INDEX_FILE_ERROR = 1
RET_FILE_EXTENSION_ERROR = 2
RET_COMMENT_NOT_PARSABLE = 3
RET_FOUND_COMMENT_MARKER_NO_HASHABLE = 4
RET_FOUND_COMMEND_MARKER_WITH_HASHABLE = 5
RET_FUNCTION_DECLARATION = 6
RET_ATTRIBUTE_ERROR = 7
RET_MISSING_FILE_AND_CMAKE_LIST = 8


def checkLibclangVersion():
    # Get the libclang version
    result = subprocess.run(
        ["clang", "--version"],
        capture_output=True,
        text=True
    )
    logger.info(f"libclang version: {result.stdout}")


def parseCMakeLists(cmakelists_path, cmake_sourcelist) -> str:
    try:
        with open(cmakelists_path, 'r') as f:
            content = f.readlines()
    except IOError:
        logger.error(
            f"Failed to open CMakeLists.txt file in path: {cmakelists_path}"
        )

    parentPath = os.path.dirname(cmakelists_path)
    for line in content:
        if line.strip().startswith('file(GLOB_RECURSE ' + cmake_sourcelist):
            parts = line.split(None, 2)
            if len(parts) == 3:
                path = parts[2].strip()
                endPos = path.rfind(')')
                return parentPath + '/' + parts[2].strip()[:endPos]

    return None


def checkIntermediateDir(dir):
    if dir:
        return dir
    else:
        return "."


def checkOutputPath(path):
    if path:
        return path
    else:
        return "."


def detect_file_encoding(file_path):
    pass


def getFileExtension(file_name):
    _, extension = os.path.splitext(file_name)
    if extension:
        return extension
    else:
        logger.error("Unable to determine file extension for {file_name}")


def getFileType(extension):
    if extension == ".cpp" or extension == ".hpp":
        return "c++"
    if extension == ".c" or extension == ".h":
        return "c"
    if extension == ".txt":
        return "cmake"

    logger.error(f"Unknown file format for {extension}")
    return "unknown"


def getEOLType(contents) -> EOLType:
    if "\r\n" in contents:
        return EOLType.CRLF
    if "\n\r" in contents:
        return EOLType.LFCR
    if "\n" in contents:
        return EOLType.LF
    if "\r" in contents:
        return EOLType.CR
    return EOLType.UNKNOWN


# TODO(Todd): This does not appear to be working correctly with a CRLF file.
# Using LF EOL files only for testing
def convertToLF(contents) -> str:
    match getEOLType(contents):
        case EOLType.LF:
            logger.info("Source file is LF EOL type - no conversion necessary")
            return contents
        case EOLType.CR:
            logger.info("Source file is EOL CR type, converting to LF")
            return contents.replace("\r", "\n")
        case EOLType.CRLF:
            logger.info("Source file is EOL CRLF type, converting to LF")
            return contents.replace("\r\n", "\n")
        case EOLType.UNKNOWN:
            pass
        case _:
            logger.info("Source file EOL type is unknown - no conversion")
            return contents


def getFileGlobs(path) -> []:
    files = []
    for file in glob.glob(path, recursive=True):
        if os.path.isfile(file):
            files.append(file)

    return files


def isLomeComment(text):
    return text[0:3] == "/*!"


def isFuncDecl(kind: clang.cindex.CursorKind):
    return (
        kind == clang.cindex.CursorKind.FUNCTION_DECL
        or kind == clang.cindex.CursorKind.CXX_METHOD
    )


def getCompoundStatement(cursor: clang.cindex.Cursor):
    for child in cursor.get_children():
        if child.kind == clang.cindex.CursorKind.COMPOUND_STMT:
            return cursor
    return None


def closeIndex(index_contents):
    result = index_contents.rfind(",")
    if result != -1:
        index_contents = index_contents[:result]
        index_contents = index_contents + "\n]\n"
    return index_contents


def genIndexEntry(comment_fragment: Fragment, output_path):
    """
    The JSON format for the index file entries is
    {
        "index_hash": string,
        "data": {
            "index_text": string,
            "fragment_text": string,
            "start_line": int
        }
    }
    """
    json_out = {}
    data = {}
    if comment_fragment.is_custom_hash:
        json_out["index_hash"] = comment_fragment.custom_index_hash
        data["index_text"] = comment_fragment.custom_index_text
    else:
        json_out["index_hash"] = comment_fragment.function_declaration_hash
        data["index_text"] = \
            comment_fragment.function_declaration_signature_text
    data["fragment_text"] = comment_fragment.function_text
    data["start_line"] = comment_fragment.start_line
    json_out["data"] = data

    return json.dumps(json_out)


def genJsonComment(comment_fragment: Fragment):
    json_out = {}
    is_comment_hash = comment_fragment.function_declaration_hash == 0
    if is_comment_hash:
        json_out["hash_index"] = comment_fragment.custom_index_hash
        json_out["hash_text"] = comment_fragment.custom_index_text
    else:
        json_out["hash_index"] = comment_fragment.function_declaration_hash
        json_out["hash_text"] = \
            comment_fragment.function_declaration_signature_text
    json_out[
        "function_signature"
    ] = comment_fragment.function_declaration_signature_text
    json_out[
        "function_declaration_signature_text"
    ] = comment_fragment.function_declaration_signature_text
    json_out["comment_text"] = comment_fragment.comment_text
    json_out["function_text"] = comment_fragment.function_text
    json_out["start_line"] = comment_fragment.start_line

    return json.dumps(json_out)


# End of genJsonComment(...)


def trySetCustomHash(fragment: Fragment):
    text = fragment.comment_text
    first_line = text.split("\n")[0].strip()
    # Assume extra characters form a custom reference string
    if len(first_line) > 3:
        fragment.custom_index_text = first_line[3:len(first_line)]
        fragment.custom_index_hash = \
            hashlib.sha256(bytes(
                fragment.custom_index_text,
                "utf-8"
            )).hexdigest()
        fragment.is_custom_hash = True
        return True

    return False


# End of trySetCustomHash(...)


def findCommentFragment(
    line_num: int, comment_fragments: List[Fragment]
) -> Tuple[int, Fragment]:
    prev_line_num = line_num - 1
    if prev_line_num < 0:
        prev_line_num = 0
    for index, comment_fragment in enumerate(comment_fragments):
        if (comment_fragment.comment_range):
            if (
                comment_fragment.comment_range.end == prev_line_num or
                comment_fragment.comment_range.end + 1 == prev_line_num
            ):
                return [index, comment_fragment]
    return [None, None]


def visitorFn(cursor):
    verbose_logger.info(f"    Cursor: {cursor.spelling}")


def parseComments(
    cursor: clang.cindex.Cursor, comment_fragments: List[Fragment]
):
    assert cursor.kind.is_translation_unit, \
        "cursor must be a translation unit kind"
    for token in cursor.get_tokens():
        if token.kind == clang.cindex.TokenKind.COMMENT:
            if isLomeComment(token.spelling):
                fragment: Fragment = Fragment()
                range: clang.cindex.SourceRange = token.extent
                fragment.comment_range = \
                    SrcRange(range.start.line, range.end.line)
                fragment.comment_text = token.spelling
                if trySetCustomHash(fragment):
                    verbose_logger.info(
                        (
                            f"Successfully hashed a custom index: "
                            f"{fragment.custom_index_text}, "
                            f"hash= {fragment.custom_index_hash}"
                        )
                    )
                comment_fragments.append(fragment)
# End of parseComments(cursor, comment_fragments)


def findEndOfScopeOffset(cursor: clang.cindex.Cursor, contents) -> int:
    brace_stack = 0
    start_brace_found = False
    for token in cursor.get_tokens():
        if token.spelling == "{":
            brace_stack += 1
            start_brace_found = True
        elif token.spelling == "}":
            brace_stack -= 1
        if start_brace_found and brace_stack == 0:
            return convertToCharacterPosition(
                token.location.offset,
                contents) + 1
    return -1
# End of FindEndOfScopeLine(...)


def isFunctionOrMethod(cursor):
    return cursor.kind == clang.cindex.CursorKind.CXX_METHOD \
        or cursor.kind == clang.cindex.CursorKind.FUNCTION_DECL


@dataclass
class CodeSection:
    found: bool = False
    extent: clang.cindex.SourceRange = clang.cindex.SourceRange()


def getNamespaceFullname(cursor):
    names = []
    while cursor.kind != clang.cindex.CursorKind.TRANSLATION_UNIT:
        names.insert(0, cursor.displayname)
        cursor = cursor.semantic_parent
    return "::".join(names)


def findMethodDefinition(cursor, codeSection: CodeSection):
    if isFunctionOrMethod(cursor) and cursor.is_definition():
        codeSection.extent = cursor.extent
        codeSection.found = True
    for child in cursor.get_children():
        findMethodDefinition(child, codeSection)


def convertToCharacterPosition(offset, contents):
    return len(contents[:offset].encode("utf-8"))


def visitorFnParseFuncFirstPass(
    cursor: clang.cindex.Cursor,
    fragments: List[Fragment],
    contents
):
    codeSection: CodeSection = CodeSection()
    fragment: Fragment = Fragment()

    verbose_logger.info(
        f"  Found CursorKind of: {cursor.kind}, {cursor.displayname}"
    )
    if isFunctionOrMethod(cursor):
        findMethodDefinition(cursor, codeSection)
        if codeSection.found:
            display_name = getNamespaceFullname(cursor)
            fragment.function_declaration_signature_text = display_name
            fragment.function_declaration_hash = \
                hashlib.sha256(bytes(display_name, "utf-8")).hexdigest()

            start = codeSection.extent.start
            end = codeSection.extent.end
            fragment.function_scope_range
            fragment.source_file_path = start.file.name if start.file else None
            verbose_logger.info(
                f"Processing source file: {fragment.source_file_path}"
            )
            fragment.function_text = getFunctionText(
                fragment.source_file_path,
                start.offset,
                end.offset) if fragment.source_file_path else ""
            fragments.append(fragment)

            verbose_logger.info(
                f"  Found {cursor.kind} for {cursor.displayname}"
                f", start line: {codeSection.extent.start.line}"
                f", end line: {cursor.extent.end.line}"
            )
            verbose_logger.info(f"    Generated fragment: {fragment}")


def visitorFnParseFuncSecondPass(
    cursor: clang.cindex.Cursor,
    comment_fragments: List[Fragment],
    contents
):
    if isFuncDecl(cursor.kind):
        line_num: clang.cindex.SourceRange = cursor.extent.start.line
        display_name = getNamespaceFullname(cursor)
        index, comment_fragment = \
            findCommentFragment(line_num, comment_fragments)
        if index is None:
            logger.error(
                f"Cannot find corresponding function declaration in: "
                f"{cursor.location}"
            )
            return
        verbose_logger.info(
            f"    Found corresponding comment of index: "
            f"{index}, {comment_fragment}"
        )
        comment_fragment.start_line = line_num
        comment_fragment.function_declaration_signature_text = (
            display_name  # return value does not form part of the signature
        )
        comment_fragment.function_declaration_hash = \
            hashlib.sha256(bytes(display_name, "utf-8")).hexdigest()
        end_of_scope = findEndOfScopeOffset(cursor, contents)
        comment_fragment.function_scope_range = SrcRange(
            convertToCharacterPosition(cursor.extent.start.offset, contents),
            end_of_scope,
        )
        definition_start = convertToCharacterPosition(
            cursor.extent.start.offset, contents
        )
        definition_end = contents.find("{", definition_start)
        if definition_end == -1:
            # If there is no '{' character, it might be a
            # function declaration without a body.
            # In this case, we take the entire range of the node.
            definition_end = convertToCharacterPosition(
                cursor.extent.end.offset, contents
            )
        comment_fragment.function_declaration_text = contents[
            definition_start:definition_end
        ]
        comment_fragment.function_declaration_text = \
            comment_fragment.function_declaration_text.strip()

        verbose_logger.info(
            "    Found parsed function from comment: "
            f"{comment_fragment}"
        )
# End of visitorFnParseFunc(...)


def cleanOrphanFragments(comment_fragments: List[Fragment]):
    for comment in comment_fragments:
        if comment.function_declaration_hash == 0:
            comment_fragments.remove(comment)


def parseFunctionDecls(
    cursor: clang.cindex.Cursor,
    comment_fragments: List[Fragment],
    contents
):
    traverse(cursor, comment_fragments, visitorFnParseFuncFirstPass, contents)
    # traverse(
    # cursor, comment_fragments, visitorFnParseFuncSecondPass, contents)


def getFunctionText(file_path, start_offset, end_offset):
    # Read the source code segment with UTF-8 encoding
    with open(file_path, 'r', encoding='utf-8') as source_file:
        source_code = source_file.read()
        function_text = source_code[start_offset:end_offset]

    return function_text


def parseFunctionText(comment_fragments: List[Fragment], contents):
    for comment_fragment in comment_fragments:
        if comment_fragment.function_declaration_hash:
            start = comment_fragment.function_scope_range.start
            end = comment_fragment.function_scope_range.end
            comment_fragment.function_text = "".join(contents[start:end])
            if comment_fragment.function_declaration_range:
                start_offset = \
                    comment_fragment.function_declaration_range.start
                end_offset = comment_fragment.function_declaration_range.end
                decl = contents[start_offset:end_offset]
                verbose_logger.info(f" function declaration: {decl}")
                comment_fragment.function_declaration_text = "".join(
                    contents[start_offset:end_offset]
                )


def traverse(
    cursor: clang.cindex.Cursor,
    comment_fragments,
    visitor, contents
):
    if visitor is not None:
        visitor(cursor, comment_fragments, contents)

    for child in cursor.get_children():
        traverse(child, comment_fragments, visitor, contents)


# End of traverse(cursor, vistor)

# Comment result enumeration
SINGLE_COMMENT_MARKER = 0
HASH_COMMENT_MARKER = 1


def getCursorFromFile(
    filename: str,
    index: clang.cindex.Index,
    args
) -> clang.cindex.TranslationUnit:
    """Returns a cursor for the given filename"""

    # We want as much details as we need to process comments
    options = clang.cindex.TranslationUnit.PARSE_DETAILED_PROCESSING_RECORD

    if not os.path.isfile(filename):
        logger.error(f"Root file read error: does {filename} exist?")
        raise FileNotFoundError(
            f"Root file read error: does {filename} exist?"
        )

    fileObj = index.parse(
        filename,
        # args=args,
        options=options
    )

    for info in fileObj.diagnostics:
        logger.info(info)

    return fileObj.cursor


def getFragmentByDeclHash(hash, fragments) -> Tuple[int, Fragment]:
    if hash == 0:
        return -1, None
    for index, fragment in enumerate(fragments):
        if hash == fragment.custom_index_hash:
            return index, fragment
    return -1, None


def joinFragments(a: List[Fragment], b: List[Fragment]) -> List[Fragment]:
    joinedList: List[Fragment] = []
    uniqueValues = set()

    for ia in a:
        verbose_logger.info(f"Processing item {ia}")
        uniqueValues.add(getattr(ia, 'function_declaration_hash'))
        joinedList.append(ia)

    for ib in b:
        verbose_logger.info(f"Processing item {ib}")
        attr = getattr(ib, 'function_declaration_hash')
        if attr not in uniqueValues:
            uniqueValues.add(attr)
            joinedList.append(ib)

    verbose_logger.info("Returning joined list")
    return joinedList


def parseFiles(
        files,
        output_path,
        intermediate_dir,
        index_file: TextIOWrapper,
        file_type
):
    fragments: Fragment = []
    comment_fragments: Fragment = []
    index = clang.cindex.Index.create()
    cursor: clang.cindex.Cursor

    for file in files:
        try:
            cursor = getCursorFromFile(
                file, index,
                [
                    "-x", file_type,
                    "-O0",
                    "-fcomplete-member-pointers",
                    "-fdelayed-template-parsing"
                ]
            )
        except clang.cindex.TranslationUnitLoadError as e:
            logger.error(f"Error parsing file: {file}\n  Error: {str(e)}")
            return
        start_cursor: clang.cindex.Cursor = cursor
        logger.info(f"Parsing file {cursor.spelling}")

        with open(file, "r", encoding="utf-8") as f:
            contents = f.read()

        contents = convertToLF(contents)

        if cursor.kind.is_translation_unit():
            verbose_logger.info(
                " Parsing translation unit functions and methods"
            )
            parseFunctionDecls(start_cursor, fragments, contents)
            verbose_logger.info(" Parsing translation unit comments...")
            parseComments(cursor, comment_fragments)
            parseFunctionText(comment_fragments, contents)
        else:
            raise ValueError(
                "First clang.cindex.Cursor must "
                "be a TRANSLATION_UNIT kind"
            )

    final_fragments = joinFragments(fragments, comment_fragments)

    out = []
    index_contents = []

    for fragment in final_fragments:
        out.append(genJsonComment(fragment))
        index_contents.append(
            genIndexEntry(fragment, output_path) + ",\n")

    index_contents_str = "[\n"
    index_contents_str = index_contents_str + "".join(index_contents)
    index_contents_str = closeIndex(index_contents_str)

    index_file.write(index_contents_str)
    verbose_logger.info(f"Wrote index file: {index_file.name}")
# end of parseFile


def runFragmenter(
        file_name,
        output_path,
        intermediate_dir,
        index_path,
        cmake_file,
        cmake_list
        ):
    global new_index_file

    index_file = open(index_path, "w")
    if index_file:
        logger.info(f"Created new file {index_path} for indexing")
    else:
        logger.error(
            f"Failed to create {index_path} for indexing"
            f" - exiting"
        )
        sys.exit(RET_INDEX_FILE_ERROR)

    file_type = getFileType(getFileExtension(file_name))
    logger.info(
        f"Detected file encoding '{detect_file_encoding(file_name)}'"
        f" for: {file_name}"
    )

    if cmake_file:
        if cmake_list is None:
            cmake_list = "SOURCEFILES"
        files = getFileGlobs(parseCMakeLists(cmake_file, cmake_list))
        verbose_logger.info(
            f"Processed files glob {cmake_list} found in {cmake_file}: {files}"
        )
    else:
        files = [file_name]

    parseFiles(files, output_path, intermediate_dir, index_file, file_type)

    return sys.exit(RET_SUCCESS)


def main():
    print(f"Lome fragmenter version {MAJOR}.{MINOR}.{PATCH}")
    global new_index_file

    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument(
        "index_path", help="Index file path for appending index entries"
    )
    arg_parser.add_argument(
        "--file",
        help="Source input file of type to be parsed"
    )
    arg_parser.add_argument(
        "-d",
        "--dir_root",
        help="Intermediate directory root"
    )
    arg_parser.add_argument("-o", "--output_path", help="Output file path")
    arg_parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )
    arg_parser.add_argument(
        "--cmake_file",
        help="CMakeLists.txt file path location - "
        "Overrides single file parsing. "
        "Uses the SOURCEFILES list - "
        "Be sure SOURCEFILES is assigned in CMakeLists.txt, "
        "or use --cmake_list=<cmake_source_file_list> argument "
        "to assign source list."
    )
    arg_parser.add_argument(
        "--cmake_list",
        help="CMake override source file list variable"
    )
    args = arg_parser.parse_args()

    if args.verbose:
        verbose_logger.setLevel(logging.NOTSET)
        logger.info("Verbose logging turned on")
    else:
        verbose_logger.setLevel(logging.FATAL)
        logger.info("Verbose logging turned off")

    input_file = ""
    if args.file:
        input_file = args.file
        logger.info(f"Found an input file: {input_file}")
    else:
        logger.error(
            "Failed to provide an input file - looking for cmake list"
        )

    if args.index_path:
        index_path = args.index_path
        logger.info(f"Found an index path: {index_path}")
    else:
        logger.error("Failed to provide an index path - exiting")
        return sys.exit(2)

    intermediate_dir = checkIntermediateDir(args.dir_root)
    if args.dir_root:
        logger.info(f"Found an intermediate directory: {intermediate_dir}")

    output_path = checkOutputPath(args.output_path)
    if args.output_path:
        logger.info(f"Found an output path: {output_path}")

    cmake_file = None
    if args.cmake_file:
        cmake_file = args.cmake_file
        logger.info(f"Found a cmake CMakeLists.txt file at: {cmake_file}")
    else:
        if input_file is None:
            logger.info("Missing CMake list and individual file - exiting")
            sys.exit(RET_MISSING_FILE_AND_CMAKE_LIST.value)

    cmake_list_var = None
    if args.cmake_list:
        cmake_list_var = args.cmake_list
        logger.info(
            "Found a CMakeLists.txt source list variable name: "
            f"{cmake_list_var}"
        )
    checkLibclangVersion()

    return runFragmenter(
        input_file,
        output_path,
        intermediate_dir,
        index_path,
        cmake_file,
        cmake_list_var
    )


# end of main()

if __name__ == "__main__":
    main()
