#!/bin/python3
# Lome Project
# @author Todd Saharchuk
# (c) Copyright 2023- , Todd Saharchuk
#
import argparse
import hashlib
import json
import logging
import os
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from typing import Tuple

logging.basicConfig()
logging.root.setLevel(logging.NOTSET)

app = "weaver"
logger = logging.getLogger(app)
logger.setLevel(logging.INFO)
app_verbose = "weaver_verbose"
verbose_logger = logging.getLogger(app_verbose)
hash = hashlib.sha256

# Global variables
MAJOR = 0
MINOR = 0
PATCH = 1
gMarkdown = False

gDocumentHeader = r"""---
header-includes:
  - \usepackage{listings}
  - \lstset{basicstyle=\ttfamily, numbersep=15pt}
  - '<style>
      code { font-family: "monospace", monospace; }
    </style>'
---

"""


# Error code enumeration
class ErrorCode(Enum):
    OK = 0
    IOERROR_ROOT_FILE_NOT_FOUND = 1
    IOERROR_INDEX_FILE_NOT_FOUND = 2
    USER_ROOT_PATH_MISSING_FAILURE = 3
    USER_INDEX_PATH_MISSING_FAILURE = 4
    LINK_FOUND = 5
    LINK_NOT_FOUND = 6
    LINK_EMPTY = 7
    LINKERROR_MALFORMED = 8
    LINK_FRAGMENT_NOT_FOUND = 9
    JSON_INDEX_FILE_ILL_FORMED = 10
    JSON_INDEX_EMPTY = 11
    OUTPUT_PATH_MISSING_FAILURE = 12
    IOERROR_OUTPUT_FILE_WRITE_FAILURE = 13
    IOERROR_OUTPUT_MD_FILE_WRITE_FAILURE = 14
    PANDOC_TOOL_NOT_FOUND = 15
    SUBRANGE_TEXT_FOUND = 16
    SUBRANGE_OUT_OF_RANGE = 17
    SUBRANGE_TEXT_ERROR = 18


@dataclass
class SubRange:
    def constructor(
            self,
            startLine: int,
            endLine: int = -1,
            empty: bool = True,
            relative: bool = True
            ):
        self.empty = empty
        self.relative = relative
        self.startLine = startLine
        self.endLine = endLine

    empty: bool = True
    relative: bool = False
    startLine: int = -1
    endLine: int = -1


def checkPandoc():
    """
    Check the environment for the pandoc utility
    """

    try:
        subprocess.run(
            ["pandoc", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True
        )

        logger.info("Found pandoc tool ...")

        return True
    except subprocess.CalledProcessError:
        logger.error("pandoc tool not found")
        sys.exit(ErrorCode.PANDOC_TOOL_NOT_FOUND.value)


def removeExtension(path):
    filename = os.path.basename(path)
    root, extension = os.path.splitext(filename)
    return os.path.join(os.path.dirname(path), root)


def getFragment(link: str, index, subRange: SubRange) \
        -> Tuple[ErrorCode, str, int]:
    if link.isdigit():
        link_hash = link
    else:
        link_hash = hash(bytes(link, "utf-8")).hexdigest()

    for obj in index:
        if obj["index_hash"] == link_hash:
            data = obj["data"]
            lines = data['fragment_text'].splitlines()
            if subRange.startLine > -1 and subRange.endLine == -1:
                text = '\n'.join(lines[subRange.startLine:]) + '\n'
            elif subRange.startLine > -1 and subRange.endLine > -1:
                text = '\n'.join(
                    lines[subRange.startLine:subRange.endLine]
                ) + '\n'
            else:
                text = data['fragment_text']

            fragment = text
            verbose_logger.info(
                f"Found link {link} in index, fragment: {fragment}"
            )
            return ErrorCode.LINK_FOUND, fragment, data["start_line"]

    return ErrorCode.LINK_NOT_FOUND, link, 0


def getSubRangeText(subRange: SubRange, text: str) -> Tuple[ErrorCode, str]:
    start = subRange.startLine
    end = subRange.endLine

    if start == -1 and end == -1:
        return (ErrorCode.SUBRANGE_TEXT_FOUND, text)

    lines = text.splitlines()
    if (start + 1) > len(lines) or end > len(lines):
        return (ErrorCode.SUBRANGE_OUT_OF_RANGE, "")

    if start > -1 and end == -1:
        return (ErrorCode.SUBRANGE_TEXT_FOUND, '\n'.join(lines[start:]) + '\n')

    if start > -1 and end > -1:
        return (
            ErrorCode.SUBRANGE_TEXT_FOUND,
            '\n'.join(lines[start:end+1]) + '\n'
        )

    return (ErrorCode.SUBRANGE_TEXT_ERROR, "")


class ParserState(Enum):
    EmptyLink = 0
    OpeningBracketFound = 1
    LinkSymbolFound = 2
    ExtractingLink = 3
    ProcessingStart = 4
    ProcessingEnd = 5


def isAlphanumWithWhitespace(char):
    return char.isalnum() or char.isspace() and char != '\n'


def extractLink(line) -> Tuple[ErrorCode, str, SubRange]:
    if line == "":
        return (ErrorCode.LINK_EMPTY, "", SubRange())
    eoLinkCharSet = ['"', '\'', '\n', '\r', '\r\n']
    state: ParserState = ParserState.EmptyLink
    linkStack = []
    startStack = []
    endStack = []

    for ch in line:
        if state == ParserState.EmptyLink:
            if ch in eoLinkCharSet:
                return (ErrorCode.LINK_NOT_FOUND, "", SubRange())
            if ch == '[':
                state = ParserState.OpeningBracketFound
                continue
            continue
        if state == ParserState.OpeningBracketFound:
            if ch == '!':
                state = ParserState.LinkSymbolFound
                continue
            else:
                return (ErrorCode.LINK_NOT_FOUND, "", SubRange())
        if state == ParserState.LinkSymbolFound:
            if ch in [']', eoLinkCharSet]:
                return (ErrorCode.LINK_NOT_FOUND, "", SubRange())
            linkStack.append(ch)
            state = ParserState.ExtractingLink
            continue
        if state == ParserState.ExtractingLink:
            if ch == ']':
                return (
                    ErrorCode.LINK_FOUND,
                    ''.join(linkStack),
                    SubRange(empty=True)
                )
            if ch in eoLinkCharSet:
                return (ErrorCode.LINKERROR_MALFORMED, "", SubRange())
            if ch == ":":
                state = ParserState.ProcessingStart
                continue
            linkStack.append(ch)
        if state == ParserState.ProcessingStart:
            if ch.isdigit():
                startStack.append(ch)
                continue
            if ch == ':':
                try:
                    start = int(''.join(startStack))
                except ValueError:
                    return (ErrorCode.LINKERROR_MALFORMED, '', SubRange())
                state = ParserState.ProcessingEnd
                continue
            if ch == ']':
                try:
                    start = int(''.join(startStack))
                except ValueError:
                    return (ErrorCode.LINKERROR_MALFORMED, '', SubRange())
                return (
                    ErrorCode.LINK_FOUND,
                    ''.join(linkStack),
                    SubRange(startLine=start)
                )
            return (ErrorCode.LINKERROR_MALFORMED, '', SubRange())
        if state == ParserState.ProcessingEnd:
            if ch.isdigit():
                endStack.append(ch)
                continue
            if ch == ']':
                try:
                    end = int(''.join(endStack))
                except ValueError:
                    return (ErrorCode.LINKERROR_MALFORMED, '', SubRange())
                return (
                    ErrorCode.LINK_FOUND,
                    ''.join(linkStack),
                    SubRange(startLine=start, endLine=end)
                )
            return (ErrorCode.LINKERROR_MALFORMED, '', SubRange())

    return (ErrorCode.LINKERROR_MALFORMED, "", SubRange())


def tryAppendLink(line, document, index) -> Tuple[ErrorCode, str]:
    errCode, link, subRange = extractLink(line)
    if errCode == ErrorCode.LINK_FOUND and link:
        errCode, fragment, start_line = getFragment(link, index, subRange)
        if errCode == ErrorCode.LINK_FOUND and fragment:
            return ErrorCode.LINK_FOUND, document + \
                f"```cpp {{.numberLines startFrom={start_line} }}\n" \
                + fragment + "\n```\n"
        else:
            return ErrorCode.LINK_FRAGMENT_NOT_FOUND, document
    else:
        return ErrorCode.LINK_NOT_FOUND, document

    return ErrorCode.LINKERROR_MALFORMED, document


def buildIndex(index_contents: str) -> []:
    try:
        verbose_logger.info(f"index_contents= {index_contents}")
        index = json.loads(index_contents)
        verbose_logger.info(f"Index: {index}")
        if index == [] or index == {}:
            logger.error("Index is empty. Exiting...")
            sys.exit(ErrorCode.JSON_INDEX_EMPTY.value)
        return index
    except json.JSONDecodeError:
        logger.error("index JSON file is ill-formed. Exiting...")
        sys.exit(ErrorCode.JSON_INDEX_FILE_ILL_FORMED.value)


def _weave(root_contents, index) -> str:
    global gDocumentHeader

    document: str = gDocumentHeader
    for line in root_contents.splitlines():
        (errCode, document) = tryAppendLink(line, document, index)
        if errCode != ErrorCode.LINK_FOUND:
            document = document + line + "\n"

    return document


def weaver(root_path, index_path, output_path, output_md):
    root_contents: str
    try:
        with open(root_path, "r", encoding="utf-8") as root_file:
            root_contents = root_file.read()
    except IOError:
        logger.error(f"Failed to open root file path: {root_path}")
        sys.exit(ErrorCode.IOERROR_ROOT_FILE_NOT_FOUND.value)
    index_contents: str
    try:
        with open(index_path, "r", encoding="utf-8") as index_file:
            index_contents = index_file.read()
            index = buildIndex(index_contents)
    except IOError:
        logger.error(f"Failed to open index file path: {index_path}")
        sys.exit(ErrorCode.IOERROR_INDEX_FILE_NOT_FOUND.value)
    checkPandoc()

    try:
        output_markdown_contents: str = _weave(root_contents, index)
        if output_markdown_contents:
            with open(output_md, "w", encoding="utf-8") as output_md_file:
                output_md_file.write(output_markdown_contents)
                logger.info(
                    "Wrote intermediate markdown file to: "
                    f"{output_md}"
                )
        else:
            logger.error("Failed to generate intermediate markdown file")
    except IOError:
        logger.error(
            "Failed to write to intermediate markdown file: "
            f"{output_md}"
        )
        sys.exit(ErrorCode.IOERROR_OUTPUT_MD_FILE_WRITE_FAILURE.value)

    commandList = [
        "pandoc",
        f"{output_md}",
        "-o",
        f"{output_path}",
        "--highlight-style=pygments"
    ]

    logger.info(f"Executing: {' '.join(commandList)}")

    subprocess.run(
        commandList,
        stderr=subprocess.PIPE,
        stdout=subprocess.PIPE
    )

    return ErrorCode.OK.value


def main():
    print(f"Lome weaver version {MAJOR}.{MINOR}.{PATCH}")
    global gMarkdown

    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument(
        "root",
        help="Source input root path - main.md, "
        "or custom root doc must be in root dir",
    )
    arg_parser.add_argument(
        "index_path",
        help="Index file path for index entries - "
        "the index file must be put in the root of the source directory",
    )
    arg_parser.add_argument("-o", "--output_path", help="Output file path")
    arg_parser.add_argument(
        "-t",
        "--output_type",
        help="Output file type: pdf, html"
    )
    arg_parser.add_argument(
        "-m",
        "--markdown",
        action="store_true",
        help="Output intermediate markdown file only"
    )
    arg_parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )

    args = arg_parser.parse_args()

    if args.verbose:
        verbose_logger.setLevel(logging.NOTSET)
        logger.info("Verbose logging turned on")
    else:
        verbose_logger.setLevel(logging.FATAL)
        logger.info("Verbose logging turned off")

    if args.root:
        root_path = args.root
        logger.info(f"Found a root path: {root_path}")
    else:
        logger.error("Failed to provide a root path - exiting")
        sys.exit(ErrorCode.USER_ROOT_PATH_MISSING_FAILURE.value)

    if args.index_path:
        index_path = args.index_path
        logger.info(f"Found an index path: {index_path}")
    else:
        logger.error("Failed to provide an index path - exiting")
        sys.exit(ErrorCode.IOERROR_INDEX_FILE_NOT_FOUND.value)

    if args.markdown:
        gMarkdown = True

    if args.output_path:
        output_md = removeExtension(args.output_path)
        output_md = output_md + ".md"
        output_path = args.output_path
        logger.info(f"Found an output path: {output_path}")
    else:
        output_md = "output.md"
        output_path = "output.pdf"
        logger.error(
            "Failed to provide an output path - "
            f"defaulting to {output_path}"
        )

    return weaver(root_path, index_path, output_path, output_md)


# end of main()

if __name__ == "__main__":
    main()
