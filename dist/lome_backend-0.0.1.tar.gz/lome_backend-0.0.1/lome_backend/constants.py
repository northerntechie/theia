# Lome Project
# @author Todd Saharchuk
# (c) Copyright 2023- , Todd Saharchuk
#

# Global variables
MAJOR = 0
MINOR = 0
PATCH = 1
